package com.example.final_exam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = new Intent();
        String edittextString = (String)getIntent().getExtras().getString("username");
        TextView username = findViewById(R.id.Home_username);
        username.setText("歡迎"+edittextString);
    }
    public void btn_bmi(View view){
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }

    public void btn_step(View view){
        Intent intent = new Intent(this, MainActivity5.class);
        startActivity(intent);
    }

    public void btn_water(View view){
        Intent intent = new Intent(this, MainActivity4.class);
        startActivity(intent);
    }

    public void btn_card(View view){
        Intent intent = new Intent(this, MainActivity6.class);
        startActivity(intent);
    }
    public void btn_calculator(View view){
        Intent intent = new Intent(this, MainActivity7.class);
        startActivity(intent);
    }
}
