package com.example.final_exam;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity4 extends AppCompatActivity implements View.OnClickListener{
    private String date,time,name,goal;
    private int sum = 0,i = 1;
    private EditText data1;
    private EditText data2;
    private EditText data3;
    private EditText data4;
    private Button btn,btn2;
    private ArrayList<CheckBox> checkboxList = new ArrayList<>();
    private TextView show;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        data1 = (EditText)findViewById(R.id.date);
        data2 = (EditText)findViewById(R.id.time);
        data3 = (EditText)findViewById(R.id.name);
        data4 = (EditText)findViewById(R.id.goal);
        checkboxList.add(findViewById(R.id.box100));
        checkboxList.add(findViewById(R.id.box200));
        checkboxList.add(findViewById(R.id.box300));
        checkboxList.add(findViewById(R.id.box400));
        checkboxList.add(findViewById(R.id.box500));
        show = (TextView) findViewById(R.id.show);
        btn = findViewById(R.id.record);
        btn2 = findViewById(R.id.reset);
        btn.setOnClickListener(this);
        btn2.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.record){
            date = data1.getText().toString();
            time = data2.getText().toString();
            name = data3.getText().toString();
            goal = data4.getText().toString();
            for(CheckBox checkBox:checkboxList){
                if (checkBox.isChecked()) {
                    sum += i * 100;
                }
                i++;
            }
            String ans = String.format("日期: %s\n時間: %s\n目標: %s\n還剩: %s\n",date,time,goal,Integer.parseInt(goal)-sum);
            show.setText(ans);

        }else{
            data1.setText("");
            data2.setText("");
            data3.setText("");
            data4.setText("");
            show.setText("");
            for(CheckBox checkBox:checkboxList){
                checkBox.setChecked(false);
            }
        }


    }
}