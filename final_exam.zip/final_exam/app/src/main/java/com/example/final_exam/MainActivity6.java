package com.example.final_exam;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Random;
public class MainActivity6 extends AppCompatActivity implements View.OnClickListener{
    private ImageButton ivBG,ivBG2,ivBG3,ivBG4,ivBG5,ivBG6,ivBG7,ivBG8,ivBG9;
    private TextView text,text2;
    private int ind;
    private String ans = "錯誤",formattedDatetime,formattedDatetime2,output="";
    public LocalDateTime startTime,endTime;
    public Duration duration;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        ivBG = findViewById(R.id.img1);ivBG2 = findViewById(R.id.img2);
        ivBG3 = findViewById(R.id.img3);ivBG4 = findViewById(R.id.img4);
        ivBG5 = findViewById(R.id.img5);ivBG6 = findViewById(R.id.img6);
        ivBG7 = findViewById(R.id.img7);ivBG8 = findViewById(R.id.img8);
        ivBG9 = findViewById(R.id.img9);text = findViewById(R.id.text);
        text2 = findViewById(R.id.text3);
    }
    public void btn_Click(View view){
        output = "";
        text2.setText("");
        cover();
        start();
        startTime = LocalDateTime.now();
        text2.setText(output+="開始時間:"+startTime);
    }

    private void start() {
        String [] ary = {"橘子","蘋果","香蕉","櫻桃","葡萄","哈密瓜","檸檬","鳳梨","西瓜"};
        Random random = new Random();
        ind = random.nextInt(10);
        text.setText(ary[ind]);
        ivBG.setOnClickListener(this);ivBG2.setOnClickListener(this);
        ivBG3.setOnClickListener(this);ivBG4.setOnClickListener(this);
        ivBG5.setOnClickListener(this);ivBG6.setOnClickListener(this);
        ivBG7.setOnClickListener(this);ivBG8.setOnClickListener(this);
        ivBG9.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.img1:
                ivBG.setBackgroundResource(R.drawable.o);
                if(ind == 0){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img2:
                ivBG2.setBackgroundResource(R.drawable.a);
                if(ind == 1){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img3:
                ivBG3.setBackgroundResource(R.drawable.b);
                if(ind == 2){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img4:
                ivBG4.setBackgroundResource(R.drawable.e);
                if(ind == 3){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img5:
                ivBG5.setBackgroundResource(R.drawable.g);
                if(ind == 4){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img6:
                ivBG6.setBackgroundResource(R.drawable.h);
                if(ind == 5){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img7:
                ivBG7.setBackgroundResource(R.drawable.l);
                if(ind == 6){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img8:
                ivBG8.setBackgroundResource(R.drawable.p);
                if(ind == 7){
                    ans="正確";
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
            case R.id.img9:
                ivBG9.setBackgroundResource(R.drawable.w);
                if(ind == 8){
                    ans="正確";
                    LocalDateTime endTime = LocalDateTime.now();
                    endTime = LocalDateTime.now();
                    duration = Duration.between(startTime, endTime);
                    long seconds = duration.getSeconds();
                    text2.setText(output+="\n結束時間"+endTime+"\n花費:"+seconds+"秒");
                }break;
        }
        text.setText(ans);
        ans = "錯誤";
    }
    public void cover(){
        ivBG.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG2.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG3.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG4.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG5.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG6.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG7.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG8.setBackgroundResource(R.drawable.ic_launcher_background);
        ivBG9.setBackgroundResource(R.drawable.ic_launcher_background);
    }
}