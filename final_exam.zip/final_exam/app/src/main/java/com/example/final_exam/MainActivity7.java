package com.example.final_exam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity7 extends AppCompatActivity {
    EditText text1,text2;
    private static final int SET_RESULT = 1;
    TextView output;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        output = findViewById(R.id.output_act7);
    }
    public void btn_click(View view){
        text1 = (EditText) findViewById(R.id.fn);
        text2 = (EditText) findViewById(R.id.sn);
        String str1 = text1.getText().toString();
        String str2 = text2.getText().toString();
        if(!str1.isEmpty()&&!str2.isEmpty()){
            Intent intent = new Intent(this, MainActivity8.class);
            Bundle bundle = new Bundle();
            bundle.putString("text1", text1.getText().toString());
            bundle.putString("text2", text2.getText().toString());
            intent.putExtras(bundle);
            startActivityForResult(intent, SET_RESULT);
        }
    }
    @Deprecated
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode,data);
        switch (requestCode){
            case SET_RESULT:
                if(resultCode == RESULT_OK){
                    Bundle bundle = data.getExtras();
                    output.setText("答案:"+
                            bundle.getString("RESULT"));
                }
                break;
        }
    }
}