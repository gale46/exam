package com.example.final_exam;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity8 extends AppCompatActivity {
    CheckBox checkBox;
    TextView textView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
        checkBox = findViewById(R.id.checkBox);
    }
    public void btn2_click(View view){
        double num1, num2, ans = 0;
        RadioGroup radioGroup;
        Bundle bundle2 = this.getIntent().getExtras();
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
        int checkRadioGroup = radioGroup.getCheckedRadioButtonId();
        if(bundle2==null)return;

        num1 = Double.parseDouble(bundle2.getString("text1"));
        num2 = Double.parseDouble(bundle2.getString("text2"));
        checkBox = findViewById(R.id.checkBox);
        if(checkRadioGroup != -1){
            if(checkBox.isChecked()){
                num1 = (int)num1;
                num2 = (int)num2;
                ans = (int)ans;
            }
            if(radioGroup.getCheckedRadioButtonId() == R.id.r1){ans = num1 + num2;}
            else if(radioGroup.getCheckedRadioButtonId() == R.id.r2){ans = num1 - num2;}
            else if(radioGroup.getCheckedRadioButtonId() == R.id.r3){ans = num1 * num2;}
            else if(radioGroup.getCheckedRadioButtonId() == R.id.r4){ans = num1 / num2;}
            Intent rIntent = new Intent();
            Bundle rbundle = new Bundle();
            rbundle.putString("RESULT", String.valueOf(ans));
            rIntent.putExtras(rbundle);
            setResult(RESULT_OK, rIntent);
            finish();
        }
    }

}