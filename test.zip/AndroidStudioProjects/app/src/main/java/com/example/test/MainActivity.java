package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView output0;
    private EditText output,output2,output3,output4;
    private RadioGroup radioGroup;
    private RadioButton radioBtn1, radioBtn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn =  findViewById(R.id.button);
        Button btn2 = findViewById(R.id.button2);
        btn.setOnClickListener(this);
        btn2.setOnClickListener(this);
        output0 = (TextView)findViewById(R.id.textView4);
        output = (EditText)findViewById(R.id.editTextNumber2);
        output2 = (EditText) findViewById(R.id.editTextNumber3);
        output3 = (EditText) findViewById(R.id.editTextNumber);
        output4 = (EditText) findViewById(R.id.editTextNumber4);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        radioBtn1 = (RadioButton) findViewById(R.id.radioButton);
        radioBtn2 = (RadioButton) findViewById(R.id.radioButton2);
    }
    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button){
            double num = Double.parseDouble(output.getText().toString()) / 100;
            double num2 = Double.parseDouble(output2.getText().toString());
            double bmi = num2/num/num;
            String name = output3.getText().toString();
            String age = output4.getText().toString();
            String gen;
            if (radioBtn1.isChecked()){
                gen = "Male";
            } else{
                gen = "Female";
            }
            String ans = String.valueOf(String.format(Locale.getDefault(),"Name: %s\nAge: %s\nGender: %s\nHeight: %.0f\nWeight: %.0f\nBMI: %.2f",name,age,gen,num*100,num2,bmi));
            output0.setText(ans);
        }
        else if (view.getId() == R.id.button2) {
            output0.setText("BMI:");
            output.setText("");
            output2.setText("");
            output3.setText("");
            output4.setText("");
            radioBtn1.setChecked(false);
            radioBtn2.setChecked(false);
        }
    }
}